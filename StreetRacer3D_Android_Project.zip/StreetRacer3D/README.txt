Street Racer 3D - Major Upgrade 9.0

Included:
- Upgraded 3D-style racing gameplay
- 3 selectable cars
- 3 city/environment themes: Night, Sunset, Neon Rain
- More traffic and progressive difficulty
- Collectible coins and saved coin bank
- Boost system with cooldown
- Improved road perspective, skyline, lights and scenery
- Touch and keyboard controls
- Pause/resume
- Music toggle and supplied soundtrack
- Sound effects for steering, coins, levels, boost and crash
- Saved best score
- Game over, race again and main menu
- New Street Racer app icon/logo
- Google Mobile Ads SDK 25.5.0 integration
- Test interstitial ad every few completed races
- Optional test rewarded ad for +50 coins
- Ad integration uses Google's official test IDs in this development build

IMPORTANT MONETIZATION NOTE:
The included ad IDs are Google's TEST IDs. They do not generate revenue. A production AdMob setup requires registering the app in an AdMob account, using production ad IDs, and completing Google's consent/privacy requirements. Do not replace the test IDs with invented values. An adult/guardian should handle any account or payment setup required for a minor.

Build:
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- compileSdk 35
- minSdk 24
- targetSdk 35
- versionCode 9
- versionName 9.0
