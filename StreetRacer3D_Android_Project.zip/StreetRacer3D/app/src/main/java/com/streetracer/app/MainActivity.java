package com.streetracer.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.graphics.Color;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewarded.OnUserEarnedRewardListener;

public class MainActivity extends Activity {
    private static final String TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712";
    private static final String TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917";
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;
    private WebView webView;
    private int racesFinished = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new GameBridge(), "AndroidAds");
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");

        // Google test ads are used in this build. Replace with your own AdMob IDs only
        // when the app is registered for production and the account/consent setup is ready.
        new Thread(() -> MobileAds.initialize(this, status -> loadAds())).start();
    }

    private void loadAds() {
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, TEST_INTERSTITIAL, request, new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(InterstitialAd ad) { interstitialAd = ad; }
            @Override public void onAdFailedToLoad(LoadAdError error) { interstitialAd = null; }
        });
        RewardedAd.load(this, TEST_REWARDED, request, new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(RewardedAd ad) { rewardedAd = ad; }
            @Override public void onAdFailedToLoad(LoadAdError error) { rewardedAd = null; }
        });
    }

    private class GameBridge {
        @JavascriptInterface public void raceFinished() {
            runOnUiThread(() -> maybeShowInterstitial());
        }
        @JavascriptInterface public void watchAdForCoins() {
            runOnUiThread(() -> showRewardedForCoins());
        }
    }

    public void maybeShowInterstitial() {
        racesFinished++;
        if (racesFinished % 3 == 0 && interstitialAd != null) {
            interstitialAd.show(this);
            interstitialAd = null;
            new Handler().postDelayed(this::loadAds, 500);
        }
    }

    public void showRewardedForCoins() {
        if (rewardedAd == null) return;
        rewardedAd.show(this, rewardItem -> {
            if (webView != null) webView.evaluateJavascript("window.addCoinsFromAd && window.addCoinsFromAd(50);", null);
        });
        rewardedAd = null;
        new Handler().postDelayed(this::loadAds, 500);
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
        }
        super.onDestroy();
    }
}
