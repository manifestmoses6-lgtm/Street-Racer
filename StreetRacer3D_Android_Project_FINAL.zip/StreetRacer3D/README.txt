Street Racer 3D Android project
Version 2.0
This project wraps the Street Racer 3D browser game in an Android WebView.
Build with Gradle 8.9 and Java 17.
