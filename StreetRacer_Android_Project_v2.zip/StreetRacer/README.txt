STREET RACER 2.0 - ANDROID PROJECT

NEW IN 2.0
- Car selection (4 cars; unlock Crimson / Cyan Bolt / Gold Rush with coins)
- Music + sound effects (generated in code, toggle on/off in menu or pause)
- Day / Night / Sunset / Neon Rain modes
- Coins saved between sessions (your bank)
- Boost: collect coins to fill the bar, tap BOOST (invincible + smashes traffic)
- Pause button + Android Back button (Back on main menu exits)
- High score saved on device
- Improved traffic: trucks, varied colors and speeds, fair spacing
- Improved controls: swipe anywhere, arrow buttons, keyboard (arrows, Space, P)
- New Street Racer logo and app icon

BUILD: open the StreetRacer folder in Android Studio > Build > Build APK(s).
Game code lives in app/src/main/assets/index.html
