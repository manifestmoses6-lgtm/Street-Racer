Street Racer 2D upgraded project.
Features: selectable cars, stable 3-lane road, improved traffic, coins, coin bank, boost, levels, themes, pause/resume, sound toggle, high score and game-over/race-again.

2D fixed build: Android asset index.html includes the upgraded game and bundled music.mp3; launcher icon uses street_racer_icon.png.
