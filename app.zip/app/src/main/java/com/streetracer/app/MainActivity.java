package com.streetracer.app;

import android.app.Activity;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.JavascriptInterface;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends Activity {
    // TEST ad unit IDs. Replace with YOUR real ad unit IDs from AdMob before publishing.
    private static final String INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";
    private static final String REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";

    private WebView gameView;
    private InterstitialAd interstitial;
    private RewardedAd rewarded;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        setContentView(R.layout.activity_main);

        gameView = findViewById(R.id.gameView);
        gameView.setWebViewClient(new WebViewClient());
        gameView.setBackgroundColor(0xFF07070D);

        WebSettings settings = gameView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        MobileAds.initialize(this, status -> { });
        loadInterstitial();
        loadRewarded();
        gameView.addJavascriptInterface(new AdBridge(), "Android");

        gameView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemBars();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Pause the race when the player leaves the app
        gameView.evaluateJavascript("window.pauseGame && window.pauseGame();", null);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
    }

    @Override
    public void onBackPressed() {
        // The game handles Back (pause / resume / menu). Exit only from the main menu.
        gameView.evaluateJavascript("window.onBack ? window.onBack() : false;", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    private void loadInterstitial() {
        InterstitialAd.load(this, INTERSTITIAL_ID, new AdRequest.Builder().build(),
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(@NonNull InterstitialAd ad) { interstitial = ad; }
                @Override public void onAdFailedToLoad(@NonNull LoadAdError e) { interstitial = null; }
            });
    }

    private void loadRewarded() {
        RewardedAd.load(this, REWARDED_ID, new AdRequest.Builder().build(),
            new RewardedAdLoadCallback() {
                @Override public void onAdLoaded(@NonNull RewardedAd ad) { rewarded = ad; }
                @Override public void onAdFailedToLoad(@NonNull LoadAdError e) { rewarded = null; }
            });
    }

    /** Methods the game (JavaScript) can call. */
    private class AdBridge {
        @JavascriptInterface
        public void showInterstitial() {
            runOnUiThread(() -> {
                if (interstitial == null) { loadInterstitial(); return; }
                interstitial.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() { interstitial = null; loadInterstitial(); }
                    @Override public void onAdFailedToShowFullScreenContent(@NonNull AdError e) { interstitial = null; loadInterstitial(); }
                });
                interstitial.show(MainActivity.this);
            });
        }

        @JavascriptInterface
        public void showRewarded() {
            runOnUiThread(() -> {
                if (rewarded == null) { loadRewarded(); return; }
                rewarded.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() { rewarded = null; loadRewarded(); }
                });
                rewarded.show(MainActivity.this, reward ->
                    gameView.post(() -> gameView.evaluateJavascript("window.onReward && window.onReward();", null)));
            });
        }
    }
}
