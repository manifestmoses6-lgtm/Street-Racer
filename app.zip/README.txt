STREET RACER 2.1 - ANDROID PROJECT

NEW IN 2.0
- Car selection (4 cars; unlock Crimson / Cyan Bolt / Gold Rush with coins)
- Music + sound effects (generated in code, toggle on/off in menu or pause)
- Day / Night / Sunset / Neon Rain modes
- Coins saved between sessions (your bank)
- Boost: collect coins to fill the bar, tap BOOST (invincible + smashes traffic)
- Pause button + Android Back button (Back on main menu exits)
- High score saved on device
- Improved traffic: trucks, varied colors and speeds, fair spacing
- Improved controls: swipe anywhere, arrow buttons, keyboard (arrows, Space, P)
- New Street Racer logo and app icon

BUILD: open the StreetRacer folder in Android Studio > Build > Build APK(s).
Game code lives in app/src/main/assets/index.html

2.1: custom music (assets/music.mp3) and AdMob ads (interstitial every 3 games + rewarded "watch ad for 50 coins").
IMPORTANT: ads use Google TEST IDs. Replace them with your real AdMob IDs (see MainActivity.java and AndroidManifest.xml).

2.2: new beat (assets/music.m4a); junctions with 3 road types (City 3 lanes, Highway 4 lanes fast, Desert 2 lanes coin-rich);
ads tied to coins: interstitial after every 30 coins collected, rewarded ad doubles the coins from the run.

2.3: RACE MODE - start line + 3-2-1 countdown, 4 rival racers, finish line, minimap with route arrows,
junctions (right way = full nitro, wrong way = slowdown), nitro pickups, finishing position rewards coins.

2.4: daily reward streak, 4-track career (stars, unlocks, boss), missions, car upgrades (speed/nitro/handling),
rival personalities, best times + ghost car of your best run, crash revive (rewarded ad).

2.5: 4 lanes on every road, only 4 cars racing (player + 3 rivals, no traffic), engine sounds for every car,
faster start (gas/brake pedals), steering wheel, redesigned car graphics, first-time how-to-play guide (also under Help).

2.6: 12 levels (road gets longer each level, more junctions, tougher rivals, bosses on 4/8/12),
coins across all 4 lanes, 🧲 magnet pickup pulls every coin to the car for 8 seconds, new magnet mission.

3.0: behind-the-car pseudo-3D view (curves, skyline, sun/moon, lamps/trees, headlights, skid marks, smoke, speed lines),
drifting charges nitro, PERFECT NITRO timing (tap when NITRO flashes green), takedowns (ram rivals while boosting),
new missions for takedowns and perfect nitros.

3.1: auto-rotate (portrait + landscape), bold black steering wheel, bold red race timer, wider road,
new modes: Elimination (last place knocked out every few seconds) and Time Trial (beat PAR time for stars).

3.2: new neon-sunset sports car app icon (adaptive + legacy) and matching menu logo.

3.3: 8-car garage (D/C/B/A/S classes, different body styles, stats and prices), rivals drive those cars at their own speeds,
every car has its own nitro (full tank at the start of every race), rivals follow the map directions,
cars roll through the finish line before the results appear.

3.3.1: fixed signing key so future updates install over the old app (progress kept). First install after this needs the old app uninstalled once.

3.3.2: real AdMob App ID + Interstitial ad unit. Rewarded still uses the test ID.

3.3.3: real Rewarded ad unit added. All AdMob IDs are now live (no test IDs left).

3.3.4: new original royalty-free music loop (generated for this game, no third-party rights).

3.3.5: menu no longer cropped on short screens; upgrades screen opaque; store assets prepared.
